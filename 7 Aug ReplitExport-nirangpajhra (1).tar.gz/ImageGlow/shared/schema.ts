import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const photos = pgTable("photos", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  filename: text("filename").notNull(),
  originalUrl: text("original_url").notNull(),
  processedUrl: text("processed_url"),
  metadata: text("metadata"), // JSON string for EXIF and processing data
  createdAt: timestamp("created_at").defaultNow(),
  fileSize: integer("file_size").notNull(),
  mimeType: text("mime_type").notNull(),
});

export const insertPhotoSchema = createInsertSchema(photos).pick({
  filename: true,
  originalUrl: true,
  processedUrl: true,
  metadata: true,
  fileSize: true,
  mimeType: true,
});

export type InsertPhoto = z.infer<typeof insertPhotoSchema>;
export type Photo = typeof photos.$inferSelect;
