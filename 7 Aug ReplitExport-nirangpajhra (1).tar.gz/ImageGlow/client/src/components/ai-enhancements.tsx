import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { enhancementPresets, EnhancementPreset } from "@/lib/image-processor";
import { Sun, Palette, Focus, Thermometer, Filter, Wand2 } from "lucide-react";

interface AIEnhancementsProps {
  currentImage: string | null;
  onSelectEnhancement: (preset: EnhancementPreset) => void;
  onAutoFix: () => void;
}

const iconMap = {
  sun: Sun,
  palette: Palette,
  focus: Focus,
  thermometer: Thermometer,
  filter: Filter,
};

export function AIEnhancements({ currentImage, onSelectEnhancement, onAutoFix }: AIEnhancementsProps) {
  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-3">
        <h4 className="text-md font-medium text-gray-900">
          AI एन्हांसमेंट विकल्प / AI Enhancement Options
        </h4>
        <Button onClick={onAutoFix} size="sm" className="flex items-center space-x-1">
          <Wand2 className="w-4 h-4" />
          <span>AI ऑटो-फिक्स / Auto-Fix</span>
        </Button>
      </div>
      
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {enhancementPresets.map((preset, index) => {
          const IconComponent = iconMap[preset.icon as keyof typeof iconMap] || Sun;
          
          return (
            <Card
              key={index}
              className="p-3 cursor-pointer hover:border-primary hover:bg-blue-50 transition-all"
              onClick={() => onSelectEnhancement(preset)}
            >
              <div className="text-center">
                {currentImage ? (
                  <div className="w-full h-24 bg-gray-200 rounded mb-2 flex items-center justify-center overflow-hidden">
                    <img 
                      src={currentImage} 
                      alt={`${preset.name} preview`}
                      className="w-full h-full object-cover"
                    />
                  </div>
                ) : (
                  <div className="w-full h-24 bg-gray-200 rounded mb-2 flex items-center justify-center">
                    <IconComponent className="w-8 h-8 text-gray-400" />
                  </div>
                )}
                <p className="text-xs font-medium text-gray-900">{preset.nameHindi}</p>
                <p className="text-xs text-gray-500">{preset.name}</p>
              </div>
            </Card>
          );
        })}
        
        <Card className="p-3 cursor-pointer hover:border-primary hover:bg-blue-50 transition-all border-2 border-dashed border-gray-300">
          <div className="text-center flex flex-col justify-center h-full" onClick={onAutoFix}>
            <Wand2 className="w-6 h-6 text-primary mx-auto mb-2" />
            <p className="text-xs font-medium text-gray-900">सभी सुधार</p>
            <p className="text-xs text-gray-500">All Combined</p>
          </div>
        </Card>
      </div>
    </div>
  );
}
