import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { ImageAdjustments } from "@/lib/image-processor";
import { Crop, RotateCw, Palette, Eraser, RotateCcw } from "lucide-react";

interface ManualToolsProps {
  adjustments: Partial<ImageAdjustments>;
  onAdjustmentChange: (adjustments: Partial<ImageAdjustments>) => void;
  onCrop: () => void;
  onRotate: (degrees: number) => void;
  onReset: () => void;
}

export function ManualTools({ 
  adjustments, 
  onAdjustmentChange, 
  onCrop, 
  onRotate, 
  onReset 
}: ManualToolsProps) {
  const handleSliderChange = (key: keyof ImageAdjustments, value: number[]) => {
    onAdjustmentChange({ [key]: value[0] });
  };

  return (
    <Card className="p-4">
      <h4 className="text-md font-medium text-gray-900 mb-4">
        मैनुअल टूल्स / Manual Tools
      </h4>
      
      {/* Adjustment Sliders */}
      <div className="space-y-4 mb-6">
        <div>
          <Label className="flex justify-between text-sm font-medium text-gray-700 mb-2">
            <span>चमक / Brightness</span>
            <span>{adjustments.brightness || 0}</span>
          </Label>
          <Slider
            value={[adjustments.brightness || 0]}
            onValueChange={(value) => handleSliderChange('brightness', value)}
            min={-100}
            max={100}
            step={1}
            className="w-full"
          />
        </div>
        
        <div>
          <Label className="flex justify-between text-sm font-medium text-gray-700 mb-2">
            <span>कंट्रास्ट / Contrast</span>
            <span>{adjustments.contrast || 0}</span>
          </Label>
          <Slider
            value={[adjustments.contrast || 0]}
            onValueChange={(value) => handleSliderChange('contrast', value)}
            min={-100}
            max={100}
            step={1}
            className="w-full"
          />
        </div>
        
        <div>
          <Label className="flex justify-between text-sm font-medium text-gray-700 mb-2">
            <span>संतृप्ति / Saturation</span>
            <span>{adjustments.saturation || 0}</span>
          </Label>
          <Slider
            value={[adjustments.saturation || 0]}
            onValueChange={(value) => handleSliderChange('saturation', value)}
            min={-100}
            max={100}
            step={1}
            className="w-full"
          />
        </div>
      </div>

      {/* Basic Tools */}
      <div className="grid grid-cols-2 gap-3 mb-6">
        <Button 
          variant="outline" 
          className="flex flex-col items-center justify-center p-3 h-auto"
          onClick={onCrop}
        >
          <Crop className="w-5 h-5 mb-1" />
          <span className="text-xs">काटें / Crop</span>
        </Button>
        
        <Button 
          variant="outline" 
          className="flex flex-col items-center justify-center p-3 h-auto"
          onClick={() => onRotate(90)}
        >
          <RotateCw className="w-5 h-5 mb-1" />
          <span className="text-xs">घुमाएं / Rotate</span>
        </Button>
        
        <Button 
          variant="outline" 
          className="flex flex-col items-center justify-center p-3 h-auto"
        >
          <Palette className="w-5 h-5 mb-1" />
          <span className="text-xs">फिल्टर / Filter</span>
        </Button>
        
        <Button 
          variant="outline" 
          className="flex flex-col items-center justify-center p-3 h-auto"
        >
          <Eraser className="w-5 h-5 mb-1" />
          <span className="text-xs">हटाएं / Remove</span>
        </Button>
      </div>

      {/* Quick Actions */}
      <div className="space-y-2">
        <Button 
          variant="outline" 
          className="w-full"
          onClick={onReset}
        >
          <RotateCcw className="w-4 h-4 mr-2" />
          रीसेट / Reset All
        </Button>
      </div>
    </Card>
  );
}
