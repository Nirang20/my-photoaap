import { useCallback, useState } from "react";
import { useDropzone } from "react-dropzone";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Upload, Images, CloudUpload } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface PhotoUploadProps {
  onUploadComplete: (imageUrl: string, photoId: string) => void;
  onBatchUpload?: (imageUrls: string[], photoIds: string[]) => void;
}

export function PhotoUpload({ onUploadComplete, onBatchUpload }: PhotoUploadProps) {
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const { toast } = useToast();

  const uploadFile = async (file: File): Promise<{ url: string; id: string }> => {
    const formData = new FormData();
    formData.append('photo', file);

    const response = await apiRequest('POST', '/api/photos/upload', formData);
    const photo = await response.json();
    
    return { url: photo.originalUrl, id: photo.id };
  };

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    if (acceptedFiles.length === 0) return;

    setIsUploading(true);
    setUploadProgress(0);

    try {
      if (acceptedFiles.length === 1) {
        // Single file upload
        const file = acceptedFiles[0];
        setUploadProgress(50);
        
        const { url, id } = await uploadFile(file);
        setUploadProgress(100);
        
        setTimeout(() => {
          onUploadComplete(url, id);
        }, 500);
      } else if (onBatchUpload) {
        // Multiple file upload
        const urls: string[] = [];
        const ids: string[] = [];
        
        for (let i = 0; i < acceptedFiles.length; i++) {
          const file = acceptedFiles[i];
          const { url, id } = await uploadFile(file);
          urls.push(url);
          ids.push(id);
          
          const progress = ((i + 1) / acceptedFiles.length) * 100;
          setUploadProgress(progress);
        }
        
        setTimeout(() => {
          onBatchUpload(urls, ids);
        }, 500);
      }

      toast({
        title: "अपलोड सफल / Upload Successful",
        description: `${acceptedFiles.length} फोटो सफलतापूर्वक अपलोड हुई / ${acceptedFiles.length} photo(s) uploaded successfully`,
      });
    } catch (error) {
      console.error('Upload failed:', error);
      toast({
        title: "अपलोड विफल / Upload Failed",
        description: "कृपया पुनः प्रयास करें / Please try again",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
    }
  }, [onUploadComplete, onBatchUpload, toast]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/jpeg': ['.jpg', '.jpeg'],
      'image/png': ['.png'],
      'image/webp': ['.webp'],
    },
    maxSize: 10 * 1024 * 1024, // 10MB
    multiple: !!onBatchUpload,
  });

  if (isUploading) {
    return (
      <Card className="p-8 text-center">
        <div className="mx-auto w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mb-4">
          <CloudUpload className="text-primary text-3xl animate-pulse" />
        </div>
        <h3 className="text-lg font-semibold text-gray-900 mb-2">
          अपलोड हो रही है...<br />
          <span className="text-sm font-normal text-gray-500">Uploading...</span>
        </h3>
        <Progress value={uploadProgress} className="w-full max-w-md mx-auto mb-4" />
        <p className="text-sm text-gray-600">
          कृपया प्रतीक्षा करें / Please wait...
        </p>
      </Card>
    );
  }

  return (
    <Card 
      {...getRootProps()} 
      className={`p-8 text-center border-2 border-dashed transition-colors cursor-pointer ${
        isDragActive 
          ? 'border-primary bg-primary/5' 
          : 'border-gray-300 hover:border-primary'
      }`}
    >
      <input {...getInputProps()} />
      
      <div className="mx-auto w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mb-4">
        <CloudUpload className="text-primary text-3xl" />
      </div>
      
      <h3 className="text-lg font-semibold text-gray-900 mb-2">
        अपनी फोटो अपलोड करें<br />
        <span className="text-sm font-normal text-gray-500">Upload Your Photo</span>
      </h3>
      
      <p className="text-gray-600 mb-6 text-sm">
        {isDragActive ? (
          <>
            फोटो यहाँ छोड़ें<br />
            <span className="text-xs text-gray-500">Drop photo here</span>
          </>
        ) : (
          <>
            फोटो को यहाँ खींचें या क्लिक करें<br />
            <span className="text-xs text-gray-500">Drag photo here or click to browse</span>
          </>
        )}
      </p>
      
      <div className="flex flex-col sm:flex-row gap-3 justify-center items-center">
        <Button className="flex items-center space-x-2 w-full sm:w-auto">
          <Upload className="w-4 h-4" />
          <span>फोटो चुनें / Choose Photo</span>
        </Button>
        
        {onBatchUpload && (
          <Button variant="outline" className="flex items-center space-x-2 w-full sm:w-auto">
            <Images className="w-4 h-4" />
            <span>कई फोटो / Multiple Photos</span>
          </Button>
        )}
      </div>
      
      <p className="text-xs text-gray-500 mt-4">
        समर्थित फॉर्मेट: JPG, PNG, WebP (Max: 10MB)<br />
        Supported formats: JPG, PNG, WebP (Max: 10MB)
      </p>
    </Card>
  );
}
