import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Eye, Wand2 } from "lucide-react";
import { AIEnhancements } from "./ai-enhancements";
import { ManualTools } from "./manual-tools";
import { OutputOptions } from "./output-options";
import { ProcessingModal } from "./processing-modal";
import { useImageProcessing } from "@/hooks/use-image-processing";
import { enhancementPresets } from "@/lib/image-processor";

interface PhotoEditorProps {
  imageUrl: string;
  photoId: string;
}

export function PhotoEditor({ imageUrl, photoId }: PhotoEditorProps) {
  const [showComparison, setShowComparison] = useState(false);
  const {
    currentImage,
    originalImage,
    adjustments,
    processingState,
    initializeProcessor,
    applyAdjustments,
    applyPreset,
    resetAdjustments,
    rotateImage,
    downloadImage,
  } = useImageProcessing();

  useEffect(() => {
    initializeProcessor(imageUrl);
  }, [imageUrl, initializeProcessor]);

  const handleAutoFix = () => {
    // Apply a combination of all enhancements
    const combinedAdjustments = enhancementPresets.reduce((acc, preset) => {
      Object.entries(preset.adjustments).forEach(([key, value]) => {
        acc[key as keyof typeof acc] = ((acc[key as keyof typeof acc] || 0) + (value || 0)) / 2;
      });
      return acc;
    }, {} as any);

    applyAdjustments(combinedAdjustments);
  };

  const handleDownload = (format: 'jpeg' | 'png') => {
    const filename = `edited-photo-${Date.now()}`;
    downloadImage(filename, format);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Photo Preview Section */}
      <div className="lg:col-span-2">
        <Card className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">
              फोटो प्रीव्यू / Photo Preview
            </h3>
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowComparison(!showComparison)}
              >
                <Eye className="w-4 h-4 mr-1" />
                {showComparison ? "केवल संपादित / Edited Only" : "पहले/बाद / Before/After"}
              </Button>
              <Button size="sm" onClick={handleAutoFix}>
                <Wand2 className="w-4 h-4 mr-1" />
                AI ऑटो-फिक्स / Auto-Fix
              </Button>
            </div>
          </div>
          
          {/* Main Photo Display */}
          <div className="bg-gray-100 rounded-lg overflow-hidden mb-4" style={{ minHeight: 400 }}>
            {showComparison && originalImage ? (
              <div className="flex h-full">
                <div className="flex-1 relative">
                  <img 
                    src={originalImage} 
                    alt="Original" 
                    className="w-full h-full object-contain"
                  />
                  <div className="absolute top-2 left-2 bg-black/70 text-white px-2 py-1 rounded text-xs">
                    पहले / Before
                  </div>
                </div>
                <div className="flex-1 relative">
                  <img 
                    src={currentImage || originalImage} 
                    alt="Edited" 
                    className="w-full h-full object-contain"
                  />
                  <div className="absolute top-2 left-2 bg-black/70 text-white px-2 py-1 rounded text-xs">
                    बाद / After
                  </div>
                </div>
              </div>
            ) : (
              <img 
                src={currentImage || imageUrl} 
                alt="Edited photo" 
                className="w-full h-full object-contain"
              />
            )}
          </div>

          {/* AI Enhancement Options */}
          <AIEnhancements
            currentImage={currentImage}
            onSelectEnhancement={applyPreset}
            onAutoFix={handleAutoFix}
          />
        </Card>
      </div>

      {/* Tools Panel */}
      <div className="space-y-6">
        <ManualTools
          adjustments={adjustments}
          onAdjustmentChange={applyAdjustments}
          onCrop={() => {}}
          onRotate={rotateImage}
          onReset={resetAdjustments}
        />
        
        <OutputOptions onDownload={handleDownload} />
      </div>

      {/* Processing Modal */}
      <ProcessingModal
        isOpen={processingState.isProcessing}
        progress={processingState.progress}
        status={processingState.status}
      />
    </div>
  );
}
