import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { Loader2 } from "lucide-react";

interface ProcessingModalProps {
  isOpen: boolean;
  progress: number;
  status: string;
}

export function ProcessingModal({ isOpen, progress, status }: ProcessingModalProps) {
  return (
    <Dialog open={isOpen}>
      <DialogContent className="sm:max-w-md">
        <div className="text-center p-6">
          <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <Loader2 className="w-8 h-8 text-primary animate-spin" />
          </div>
          
          <h3 className="text-lg font-semibold text-gray-900 mb-2">
            AI प्रोसेसिंग / AI Processing
          </h3>
          
          <p className="text-gray-600 text-sm mb-4">
            आपकी फोटो को बेहतर बनाया जा रहा है...<br />
            <span className="text-xs">Enhancing your photo...</span>
          </p>
          
          <Progress value={progress} className="w-full mb-2" />
          
          <p className="text-xs text-gray-500">
            {status}
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}