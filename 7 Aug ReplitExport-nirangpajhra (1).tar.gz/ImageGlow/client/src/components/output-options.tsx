import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Download, Share2, Facebook, Instagram } from "lucide-react";
import { SiWhatsapp } from "react-icons/si";
import { useToast } from "@/hooks/use-toast";

interface OutputOptionsProps {
  onDownload: (format: 'jpeg' | 'png') => void;
}

export function OutputOptions({ onDownload }: OutputOptionsProps) {
  const [watermark, setWatermark] = useState(false);
  const [keepEXIF, setKeepEXIF] = useState(true);
  const { toast } = useToast();

  const handleShare = (platform: string) => {
    toast({
      title: `${platform} पर शेयर`,
      description: `${platform} पर शेयर कर रहे हैं... / Sharing to ${platform}...`,
    });
  };

  return (
    <Card className="p-4">
      <h4 className="text-md font-medium text-gray-900 mb-4">
        आउटपुट विकल्प / Output Options
      </h4>
      
      {/* Download Options */}
      <div className="space-y-3 mb-4">
        <Button 
          className="w-full bg-secondary text-white hover:bg-green-700"
          onClick={() => onDownload('jpeg')}
        >
          <Download className="w-4 h-4 mr-2" />
          डाउनलोड / Download
        </Button>
        
        <div className="grid grid-cols-2 gap-2">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => onDownload('jpeg')}
          >
            JPEG
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => onDownload('png')}
          >
            PNG
          </Button>
        </div>
      </div>

      {/* Share Options */}
      <div className="border-t pt-4">
        <p className="text-sm font-medium text-gray-700 mb-3">शेयर करें / Share</p>
        <div className="grid grid-cols-3 gap-2">
          <Button 
            className="flex flex-col items-center justify-center p-2 bg-blue-600 text-white hover:bg-blue-700 h-auto"
            onClick={() => handleShare('Facebook')}
          >
            <Facebook className="w-4 h-4 mb-1" />
            <span className="text-xs">Facebook</span>
          </Button>
          
          <Button 
            className="flex flex-col items-center justify-center p-2 bg-pink-600 text-white hover:bg-pink-700 h-auto"
            onClick={() => handleShare('Instagram')}
          >
            <Instagram className="w-4 h-4 mb-1" />
            <span className="text-xs">Instagram</span>
          </Button>
          
          <Button 
            className="flex flex-col items-center justify-center p-2 bg-green-600 text-white hover:bg-green-700 h-auto"
            onClick={() => handleShare('WhatsApp')}
          >
            <SiWhatsapp className="w-4 h-4 mb-1" />
            <span className="text-xs">WhatsApp</span>
          </Button>
        </div>
      </div>

      {/* Extra Options */}
      <div className="border-t pt-4 mt-4">
        <p className="text-sm font-medium text-gray-700 mb-3">अतिरिक्त / Extras</p>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <Label htmlFor="watermark" className="text-sm text-gray-700">
              वॉटरमार्क / Watermark
            </Label>
            <Switch
              id="watermark"
              checked={watermark}
              onCheckedChange={setWatermark}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <Label htmlFor="exif" className="text-sm text-gray-700">
              EXIF डेटा रखें / Keep EXIF
            </Label>
            <Switch
              id="exif"
              checked={keepEXIF}
              onCheckedChange={setKeepEXIF}
            />
          </div>
        </div>
      </div>
    </Card>
  );
}
