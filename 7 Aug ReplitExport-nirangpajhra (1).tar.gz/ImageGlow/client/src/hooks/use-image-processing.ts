import { useState, useCallback, useRef } from "react";
import { ImageProcessor, ImageAdjustments, EnhancementPreset } from "@/lib/image-processor";

export interface ProcessingState {
  isProcessing: boolean;
  progress: number;
  status: string;
}

export function useImageProcessing() {
  const [currentImage, setCurrentImage] = useState<string | null>(null);
  const [originalImage, setOriginalImage] = useState<string | null>(null);
  const [adjustments, setAdjustments] = useState<Partial<ImageAdjustments>>({
    brightness: 0,
    contrast: 0,
    saturation: 0,
    hue: 0,
    sharpness: 0,
    noise: 0,
  });
  const [processingState, setProcessingState] = useState<ProcessingState>({
    isProcessing: false,
    progress: 0,
    status: "",
  });

  const processorRef = useRef<ImageProcessor | null>(null);

  const initializeProcessor = useCallback(async (imageUrl: string) => {
    try {
      setProcessingState({
        isProcessing: true,
        progress: 20,
        status: "विश्लेषण हो रहा है... / Analyzing...",
      });

      const processor = new ImageProcessor();
      const img = await processor.loadImage(imageUrl);
      
      setProcessingState(prev => ({
        ...prev,
        progress: 60,
        status: "प्रोसेसिंग... / Processing...",
      }));

      processor.setupCanvas(img);
      processorRef.current = processor;
      
      setOriginalImage(imageUrl);
      setCurrentImage(imageUrl);
      
      setProcessingState({
        isProcessing: false,
        progress: 100,
        status: "पूर्ण / Complete",
      });

      return processor;
    } catch (error) {
      console.error("Failed to initialize processor:", error);
      setProcessingState({
        isProcessing: false,
        progress: 0,
        status: "त्रुटि / Error",
      });
      throw error;
    }
  }, []);

  const applyAdjustments = useCallback((newAdjustments: Partial<ImageAdjustments>) => {
    if (!processorRef.current) return;

    const updatedAdjustments = { ...adjustments, ...newAdjustments };
    const processedImage = processorRef.current.applyAdjustments(updatedAdjustments);
    
    setAdjustments(updatedAdjustments);
    setCurrentImage(processedImage);
  }, [adjustments]);

  const applyPreset = useCallback((preset: EnhancementPreset) => {
    if (!processorRef.current) return;

    setProcessingState({
      isProcessing: true,
      progress: 50,
      status: `${preset.nameHindi} लागू कर रहे हैं... / Applying ${preset.name}...`,
    });

    setTimeout(() => {
      const processedImage = processorRef.current!.applyPreset(preset);
      setAdjustments(prev => ({ ...prev, ...preset.adjustments }));
      setCurrentImage(processedImage);
      
      setProcessingState({
        isProcessing: false,
        progress: 100,
        status: "पूर्ण / Complete",
      });
    }, 1000);
  }, []);

  const resetAdjustments = useCallback(() => {
    if (!processorRef.current || !originalImage) return;

    const resetAdj = {
      brightness: 0,
      contrast: 0,
      saturation: 0,
      hue: 0,
      sharpness: 0,
      noise: 0,
    };

    setAdjustments(resetAdj);
    setCurrentImage(originalImage);
  }, [originalImage]);

  const cropImage = useCallback((x: number, y: number, width: number, height: number) => {
    if (!processorRef.current) return;

    const croppedImage = processorRef.current.cropImage(x, y, width, height);
    setCurrentImage(croppedImage);
  }, []);

  const rotateImage = useCallback((degrees: number) => {
    if (!processorRef.current) return;

    const rotatedImage = processorRef.current.rotateImage(degrees);
    setCurrentImage(rotatedImage);
  }, []);

  const downloadImage = useCallback((filename: string, format: 'jpeg' | 'png' = 'jpeg') => {
    if (!processorRef.current) return;

    processorRef.current.downloadImage(filename, format);
  }, []);

  return {
    currentImage,
    originalImage,
    adjustments,
    processingState,
    initializeProcessor,
    applyAdjustments,
    applyPreset,
    resetAdjustments,
    cropImage,
    rotateImage,
    downloadImage,
    processor: processorRef.current,
  };
}
