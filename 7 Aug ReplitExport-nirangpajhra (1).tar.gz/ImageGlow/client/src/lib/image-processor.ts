export interface ImageAdjustments {
  brightness: number;
  contrast: number;
  saturation: number;
  hue: number;
  sharpness: number;
  noise: number;
}

export interface EnhancementPreset {
  name: string;
  nameHindi: string;
  adjustments: Partial<ImageAdjustments>;
  icon: string;
}

export const enhancementPresets: EnhancementPreset[] = [
  {
    name: "Brightness",
    nameHindi: "चमक सुधार",
    adjustments: { brightness: 20, contrast: 10 },
    icon: "sun",
  },
  {
    name: "Color",
    nameHindi: "रंग सुधार",
    adjustments: { saturation: 25, hue: 5 },
    icon: "palette",
  },
  {
    name: "Sharpness",
    nameHindi: "तीक्ष्णता",
    adjustments: { sharpness: 30, contrast: 15 },
    icon: "focus",
  },
  {
    name: "White Balance",
    nameHindi: "व्हाइट बैलेंस",
    adjustments: { hue: -10, saturation: 15 },
    icon: "thermometer",
  },
  {
    name: "Noise Reduction",
    nameHindi: "नॉइज़ कम",
    adjustments: { noise: -40, sharpness: 10 },
    icon: "filter",
  },
];

export class ImageProcessor {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private originalImageData: ImageData | null = null;

  constructor() {
    this.canvas = document.createElement('canvas');
    this.ctx = this.canvas.getContext('2d')!;
  }

  loadImage(imageUrl: string): Promise<HTMLImageElement> {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => resolve(img);
      img.onerror = reject;
      img.src = imageUrl;
    });
  }

  setupCanvas(img: HTMLImageElement): void {
    this.canvas.width = img.width;
    this.canvas.height = img.height;
    this.ctx.drawImage(img, 0, 0);
    this.originalImageData = this.ctx.getImageData(0, 0, img.width, img.height);
  }

  applyAdjustments(adjustments: Partial<ImageAdjustments>): string {
    if (!this.originalImageData) return '';

    // Reset to original image
    this.ctx.putImageData(this.originalImageData, 0, 0);
    
    const imageData = this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height);
    const data = imageData.data;

    // Apply brightness and contrast
    const brightness = (adjustments.brightness || 0) / 100;
    const contrast = (adjustments.contrast || 0) / 100;
    const saturation = (adjustments.saturation || 0) / 100;

    for (let i = 0; i < data.length; i += 4) {
      // Get RGB values
      let r = data[i];
      let g = data[i + 1];
      let b = data[i + 2];

      // Apply brightness
      r += brightness * 255;
      g += brightness * 255;
      b += brightness * 255;

      // Apply contrast
      r = ((r / 255 - 0.5) * (1 + contrast) + 0.5) * 255;
      g = ((g / 255 - 0.5) * (1 + contrast) + 0.5) * 255;
      b = ((b / 255 - 0.5) * (1 + contrast) + 0.5) * 255;

      // Apply saturation
      if (saturation !== 0) {
        const gray = 0.299 * r + 0.587 * g + 0.114 * b;
        r = gray + (r - gray) * (1 + saturation);
        g = gray + (g - gray) * (1 + saturation);
        b = gray + (b - gray) * (1 + saturation);
      }

      // Clamp values
      data[i] = Math.max(0, Math.min(255, r));
      data[i + 1] = Math.max(0, Math.min(255, g));
      data[i + 2] = Math.max(0, Math.min(255, b));
    }

    this.ctx.putImageData(imageData, 0, 0);
    return this.canvas.toDataURL('image/jpeg', 0.9);
  }

  applyPreset(preset: EnhancementPreset): string {
    return this.applyAdjustments(preset.adjustments);
  }

  cropImage(x: number, y: number, width: number, height: number): string {
    if (!this.originalImageData) return '';
    
    const croppedCanvas = document.createElement('canvas');
    const croppedCtx = croppedCanvas.getContext('2d')!;
    
    croppedCanvas.width = width;
    croppedCanvas.height = height;
    
    croppedCtx.drawImage(this.canvas, x, y, width, height, 0, 0, width, height);
    
    return croppedCanvas.toDataURL('image/jpeg', 0.9);
  }

  rotateImage(degrees: number): string {
    if (!this.originalImageData) return '';
    
    const rotatedCanvas = document.createElement('canvas');
    const rotatedCtx = rotatedCanvas.getContext('2d')!;
    
    const radians = (degrees * Math.PI) / 180;
    const sin = Math.abs(Math.sin(radians));
    const cos = Math.abs(Math.cos(radians));
    
    rotatedCanvas.width = this.canvas.height * sin + this.canvas.width * cos;
    rotatedCanvas.height = this.canvas.height * cos + this.canvas.width * sin;
    
    rotatedCtx.translate(rotatedCanvas.width / 2, rotatedCanvas.height / 2);
    rotatedCtx.rotate(radians);
    rotatedCtx.drawImage(this.canvas, -this.canvas.width / 2, -this.canvas.height / 2);
    
    return rotatedCanvas.toDataURL('image/jpeg', 0.9);
  }

  downloadImage(filename: string, format: 'jpeg' | 'png' = 'jpeg'): void {
    const link = document.createElement('a');
    link.download = `${filename}.${format}`;
    link.href = this.canvas.toDataURL(`image/${format}`, 0.9);
    link.click();
  }

  getCanvas(): HTMLCanvasElement {
    return this.canvas;
  }
}
