import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Wand2, Languages, HelpCircle } from "lucide-react";
import { PhotoUpload } from "@/components/photo-upload";
import { PhotoEditor } from "@/components/photo-editor";

export default function Home() {
  const [currentPhoto, setCurrentPhoto] = useState<{
    url: string;
    id: string;
  } | null>(null);
  const [showEditor, setShowEditor] = useState(false);

  const handleUploadComplete = (imageUrl: string, photoId: string) => {
    setCurrentPhoto({ url: imageUrl, id: photoId });
    setShowEditor(true);
  };

  const handleNewPhoto = () => {
    setCurrentPhoto(null);
    setShowEditor(false);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Wand2 className="text-white text-lg" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">AI फोटो एडिटर</h1>
                <p className="text-xs text-gray-500">AI Photo Editor</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="ghost" size="sm">
                <Languages className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="sm">
                <HelpCircle className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {!showEditor ? (
          /* Upload Section */
          <div className="mb-8">
            <PhotoUpload onUploadComplete={handleUploadComplete} />
          </div>
        ) : (
          /* Editing Interface */
          <>
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900">
                फोटो संपादन / Photo Editing
              </h2>
              <Button variant="outline" onClick={handleNewPhoto}>
                नई फोटो / New Photo
              </Button>
            </div>
            {currentPhoto && (
              <PhotoEditor 
                imageUrl={currentPhoto.url} 
                photoId={currentPhoto.id} 
              />
            )}
          </>
        )}
      </main>

      {/* Mobile Bottom Actions */}
      {showEditor && (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg p-4 lg:hidden">
          <div className="flex space-x-2">
            <Button className="flex-1">
              <Wand2 className="w-4 h-4 mr-2" />
              AI प्रोसेस / Process
            </Button>
            <Button variant="outline">
              टूल्स / Tools
            </Button>
            <Button variant="outline" className="bg-secondary text-white hover:bg-green-700">
              डाउनलोड / Download
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
