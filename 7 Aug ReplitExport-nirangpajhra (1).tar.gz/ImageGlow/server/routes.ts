import type { Express, Request } from "express";
import express from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import path from "path";
import fs from "fs";
import { storage } from "./storage";
import { insertPhotoSchema } from "@shared/schema";

// Configure multer for file uploads
const upload = multer({
  dest: 'uploads/',
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req: any, file: any, cb: any) => {
    const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only JPEG, PNG, and WebP are allowed.'));
    }
  },
});

// Ensure uploads directory exists
const uploadsDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Upload photo endpoint
  app.post("/api/photos/upload", upload.single('photo'), async (req: any, res) => {
    try {
      console.log('Upload request received');
      console.log('Request headers:', req.headers);
      console.log('Request file:', req.file);
      console.log('Request body keys:', Object.keys(req.body || {}));
      
      if (!req.file) {
        console.log('No file found in request');
        return res.status(400).json({ message: "No file uploaded" });
      }

      const photoData = {
        filename: req.file.originalname,
        originalUrl: `/uploads/${req.file.filename}`,
        fileSize: req.file.size,
        mimeType: req.file.mimetype,
        metadata: JSON.stringify({
          uploadDate: new Date().toISOString(),
          originalName: req.file.originalname,
        }),
      };

      const validatedData = insertPhotoSchema.parse(photoData);
      const photo = await storage.createPhoto(validatedData);

      res.json(photo);
    } catch (error) {
      console.error('Upload error:', error);
      res.status(500).json({ message: "Failed to upload photo" });
    }
  });

  // Get photo by ID
  app.get("/api/photos/:id", async (req, res) => {
    try {
      const photo = await storage.getPhoto(req.params.id);
      if (!photo) {
        return res.status(404).json({ message: "Photo not found" });
      }
      res.json(photo);
    } catch (error) {
      console.error('Get photo error:', error);
      res.status(500).json({ message: "Failed to get photo" });
    }
  });

  // Update photo (for processed versions)
  app.patch("/api/photos/:id", async (req, res) => {
    try {
      const updates = req.body;
      const photo = await storage.updatePhoto(req.params.id, updates);
      if (!photo) {
        return res.status(404).json({ message: "Photo not found" });
      }
      res.json(photo);
    } catch (error) {
      console.error('Update photo error:', error);
      res.status(500).json({ message: "Failed to update photo" });
    }
  });

  // Serve uploaded files
  app.use('/uploads', express.static(uploadsDir));

  const httpServer = createServer(app);
  return httpServer;
}
