# Overview

This is an AI-powered photo editing application that allows users to upload, enhance, and edit photos using both AI-driven enhancements and manual adjustment tools. The application provides a bilingual interface (English/Hindi) and offers features like brightness adjustment, color enhancement, noise reduction, and automated photo fixes. Users can apply various enhancement presets, make manual adjustments with sliders, and download their edited photos in different formats.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture

The frontend is built using React with TypeScript and follows a modern component-based architecture:

- **Framework**: React 18 with TypeScript for type safety
- **Routing**: Wouter for lightweight client-side routing
- **Styling**: Tailwind CSS with shadcn/ui component library for consistent design
- **State Management**: TanStack Query for server state management and custom hooks for local state
- **File Upload**: React Dropzone for drag-and-drop file uploads with validation
- **Form Handling**: React Hook Form with Zod validation schemas
- **UI Components**: Comprehensive shadcn/ui component system with Radix UI primitives

The application uses a modular component structure with dedicated components for photo upload, image editing tools, AI enhancements, manual adjustments, and output options. The frontend communicates with the backend through a centralized API client that handles HTTP requests and error management.

## Backend Architecture

The backend follows a REST API architecture built with Express.js:

- **Framework**: Express.js with TypeScript for the HTTP server
- **File Processing**: Multer for handling multipart file uploads with size and type validation
- **Storage Strategy**: Pluggable storage interface with in-memory implementation for development
- **Request Handling**: Centralized route registration with error handling middleware
- **Development Tools**: Custom logging middleware for API request monitoring

The server implements a clean separation between route handlers, storage abstraction, and business logic. File uploads are processed with validation for image types (JPEG, PNG, WebP) and size limits (10MB).

## Data Storage Solutions

The application uses a hybrid approach for data persistence:

- **Database**: PostgreSQL configured through Drizzle ORM for structured data
- **File Storage**: Local filesystem storage for uploaded images with organized directory structure
- **Schema Management**: Drizzle Kit for database migrations and schema evolution
- **Development Storage**: In-memory storage implementation for rapid development and testing

The database schema includes a photos table with metadata fields for filename, URLs, file size, MIME type, and processing information stored as JSON.

## Image Processing Architecture

The frontend implements a client-side image processing system:

- **Canvas API**: HTML5 Canvas for real-time image manipulation and preview
- **Enhancement Presets**: Predefined adjustment combinations for common photo improvements
- **Manual Controls**: Granular adjustment sliders for brightness, contrast, saturation, hue, sharpness, and noise reduction
- **Processing Pipeline**: Modular image processor class that applies adjustments non-destructively

## Authentication and Authorization

Currently, the application operates without authentication, allowing open access to photo editing features. This design choice prioritizes simplicity and immediate usability for the target use case.

# External Dependencies

## Core Framework Dependencies

- **@neondatabase/serverless**: PostgreSQL database connection for serverless environments
- **drizzle-orm**: Type-safe database ORM with PostgreSQL dialect
- **express**: Web application framework for the backend API
- **vite**: Frontend build tool and development server
- **react**: Core frontend framework with TypeScript support

## UI and Styling Dependencies

- **@radix-ui/***: Comprehensive set of unstyled UI primitives for accessibility
- **tailwindcss**: Utility-first CSS framework for styling
- **class-variance-authority**: Utility for managing conditional CSS classes
- **lucide-react**: Icon library for consistent iconography

## Image Processing Dependencies

- **multer**: Node.js middleware for handling multipart/form-data uploads
- **react-dropzone**: React component for drag-and-drop file uploads

## Development and Build Tools

- **typescript**: Static type checking for both frontend and backend
- **tsx**: TypeScript execution engine for development
- **esbuild**: Fast JavaScript bundler for production builds
- **@replit/vite-plugin-***: Replit-specific development tools and error handling

## State Management

- **@tanstack/react-query**: Server state management and caching
- **react-hook-form**: Form state management with validation
- **@hookform/resolvers**: Validation resolvers for react-hook-form
- **zod**: Runtime type validation and schema definition

The application is designed to work in Replit's cloud environment with specific tooling for development experience and deployment optimization.